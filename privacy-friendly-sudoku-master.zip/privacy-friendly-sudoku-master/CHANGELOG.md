Changelog
==========

Version 2.1.2 *(2018-01-19)*
----------------------------

 * Bug Fixing


Version 2.1.1 *(2017-06-29)*
----------------------------

 * New Tutorial
 * Bug Fixing


Version 2.1.0 *(2017-06-25)*
----------------------------

 * New difficulity level added
 * New settings
 * DB restructuring
	

Version 2.0.1 *(2016-11-07)*
----------------------------

 * Splash Screen added


Version 2.0 *(2016-10-15)*
----------------------------

 * Optimization of the level generator to save battery life
 * Design-Update
 * New Logo
 * French translation updated


Version 1.1 *(2016-03-29)*
----------------------------

 * French translation updated


Version 1.0 *(2016-03-22)*
----------------------------

 * Initial Release
