package org.secuso.privacyfriendlysudoku.ui.listener;

/**
 * Created by Chris on 19.01.2016.
 */
public interface IResetDialogFragmentListener {
    public void onResetDialogPositiveClick();
    public void onDialogNegativeClick();
}
